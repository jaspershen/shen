"""
Author:  Samantha Piekos
Date:  6/28/18
Class:  Gene 218

This program simulates a bicycle shop. It accepts from the user the user the number of bicycles that
need fixing. It querries the user if a bike has been fixed, terminating when there are no more bicycles
that need to be fixed.
"""

# accepts int from user for the number of bikes to fix
# throws an error if user input is not an int
def getNumOfBikesToFix():
        brokenBicycles = input("How many bicycles need to be fixed today? ")
        while not brokenBicycles.isdigit():
                print("Error:  incorrect input. Please input an integer.")
                brokenBicycles = input("How many bicycles need to be fixed today? ")
        return int(brokenBicycles)

# querries the user whether a bike is fixed throwing an error if not accepted input
# counts down number of bikes as they are fixed terminating when bikes remaining is 0
def fixBikes(brokenBicycles):
        while brokenBicycles > 0:
                print(brokenBicycles)
                print("Bikes are broken")
                acceptedInput = ["yes", "no", "y", "n"]
                userInput = input("Is the most recent bike fixed? ").lower()
                if userInput in acceptedInput:
                        if userInput == "yes" or userInput == "y":
                                brokenBicycles -= 1
                # throw error message if incorrect input
                else:
                        while userInput not in acceptedInput:
                                print("Error:  incorrect input. Please input one of the following 'yes', 'no', 'y', or 'n'.")
                                userInput = input("Is the most recent bike fixed? ").lower()
                        if userInput == "yes" or userInput == "y":
                                brokenBicycles -= 1

brokenBicycles = getNumOfBikesToFix()
fixBikes(brokenBicycles)
print("The last bike is fixed, you can go home.")
